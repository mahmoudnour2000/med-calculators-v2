<?php
/**
 * Plugin Name: Med Calculators
 * Plugin URI: https://example.com/med-calculators
 * Description: Professional medical calculators including pregnancy due date, ovulation window, and calorie needs calculators.
 * Version: 1.0.8
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: med-calculators
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.4
 *
 * @package MedCalculators
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Plugin constants
 */
define( 'MED_CALC_VERSION', '1.0.8' );
define( 'MED_CALC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'MED_CALC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'MED_CALC_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Hide Elementor notices IMMEDIATELY (before any other code runs)
 * This must run as early as possible to catch Elementor errors
 */
if ( is_admin() && ( isset( $_GET['elementor-preview'] ) || 
                     ( isset( $_GET['action'] ) && $_GET['action'] === 'elementor' ) ||
                     ( isset( $_GET['post'] ) && isset( $_GET['action'] ) && $_GET['action'] === 'edit' ) ) ) {
    
    // Suppress Elementor-related notices via error handler
    set_error_handler( function( $errno, $errstr, $errfile, $errline ) {
        // Check if this is an Elementor-related notice
        if ( ( $errno === E_NOTICE || $errno === E_WARNING ) &&
             ( stripos( $errstr, 'WP_Scripts::add' ) !== false || 
               stripos( $errstr, 'WP_Styles::add' ) !== false ) &&
             ( stripos( $errstr, 'elementor' ) !== false || 
               stripos( $errstr, 'elementor-v2' ) !== false ) ) {
            // Suppress this notice completely
            return true;
        }
        // Let other errors through
        return false;
    }, E_NOTICE | E_WARNING );
    
    // Also suppress via wp_php_error_args filter (WordPress 6.9.1+)
    add_filter( 'wp_php_error_args', function( $args, $error ) {
        if ( isset( $error['message'] ) ) {
            $message = $error['message'];
            if ( ( stripos( $message, 'WP_Scripts::add' ) !== false || 
                   stripos( $message, 'WP_Styles::add' ) !== false ) &&
                 ( stripos( $message, 'elementor' ) !== false || 
                   stripos( $message, 'elementor-v2' ) !== false ) ) {
                // Return empty array to suppress
                return array();
            }
        }
        return $args;
    }, 9999, 2 );
    
    // Reduce error reporting level
    add_action( 'init', function() {
        error_reporting( E_ALL & ~E_NOTICE & ~E_WARNING );
    }, 1 );
}

/**
 * Autoload classes
 */
spl_autoload_register( function( $class_name ) {
    // Only autoload our plugin classes
    if ( strpos( $class_name, 'Med_Calc_' ) !== 0 ) {
        return;
    }

    // Convert class name to file name
    $class_file = str_replace( 'Med_Calc_', '', $class_name );
    $class_file = strtolower( str_replace( '_', '-', $class_file ) );
    
    // Check in includes directory
    $file_path = MED_CALC_PLUGIN_DIR . 'includes/class-' . $class_file . '.php';
    
    if ( file_exists( $file_path ) ) {
        require_once $file_path;
        return;
    }
    
    // Check in calculators directory
    $calc_path = MED_CALC_PLUGIN_DIR . 'includes/calculators/class-' . $class_file . '.php';
    
    if ( file_exists( $calc_path ) ) {
        require_once $calc_path;
    }
});

/**
 * Initialize the plugin
 */
function med_calc_init() {
    // Load text domain for translations
    load_plugin_textdomain( 
        'med-calculators', 
        false, 
        dirname( MED_CALC_PLUGIN_BASENAME ) . '/languages' 
    );

    // ── PHP-based translation fallback (guaranteed to work) ──
    // The .mo binary file can be unreliable, so we load translations
    // directly from a PHP array and inject them via the gettext filter.
    med_calc_load_php_translations();
    
    // Hide Elementor editor notices/errors
    med_calc_hide_elementor_notices();
    
    // Add CSS/JS to hide Elementor notices
    med_calc_add_elementor_notice_hider();
    
    // Initialize the loader
    $loader = new Med_Calc_Loader();
    $loader->init();
}
add_action( 'plugins_loaded', 'med_calc_init' );

/**
 * Hide Elementor editor notices/errors.
 *
 * Suppresses WP_Scripts::add and WP_Styles::add notices that appear
 * in Elementor editor pages. These are Elementor's internal issues
 * and don't affect functionality.
 *
 * @return void
 */
function med_calc_hide_elementor_notices() {
    // Additional cleanup - this runs after early suppression
    // Start output buffering early to catch any printed notices
    add_action( 'admin_init', function() {
        if ( ! ob_get_level() ) {
            ob_start( function( $buffer ) {
                // Remove Elementor notices from HTML output
                $patterns = array(
                    '/<p[^>]*class="[^"]*notice[^"]*"[^>]*>.*?Notice:.*?WP_Scripts::add.*?elementor.*?<\/p>/is',
                    '/<p[^>]*class="[^"]*notice[^"]*"[^>]*>.*?Notice:.*?WP_Styles::add.*?elementor.*?<\/p>/is',
                    '/<p[^>]*>.*?Notice:.*?WP_Scripts::add.*?elementor.*?<\/p>/is',
                    '/<p[^>]*>.*?Notice:.*?WP_Styles::add.*?elementor.*?<\/p>/is',
                    '/Notice:.*?WP_Scripts::add.*?elementor.*?<br\s*\/?>/is',
                    '/Notice:.*?WP_Styles::add.*?elementor.*?<br\s*\/?>/is',
                    '/<div[^>]*>.*?Notice:.*?WP_Scripts::add.*?elementor.*?<\/div>/is',
                    '/<div[^>]*>.*?Notice:.*?WP_Styles::add.*?elementor.*?<\/div>/is',
                );
                foreach ( $patterns as $pattern ) {
                    $buffer = preg_replace( $pattern, '', $buffer );
                }
                return $buffer;
            });
        }
    }, 1 );
}

/**
 * Add CSS and JavaScript to hide Elementor notices in admin.
 *
 * @return void
 */
function med_calc_add_elementor_notice_hider() {
    // Check if we're in Elementor editor
    $is_elementor = false;
    if ( is_admin() ) {
        if ( isset( $_GET['elementor-preview'] ) || 
             ( isset( $_GET['action'] ) && $_GET['action'] === 'elementor' ) ||
             ( isset( $_GET['post'] ) && isset( $_GET['action'] ) && $_GET['action'] === 'edit' ) ) {
            $is_elementor = true;
        }
    }
    
    if ( ! $is_elementor ) {
        return;
    }
    
    // Add CSS to hide notices
    add_action( 'admin_head', function() {
        echo '<style>
            /* Hide Elementor-related notices */
            .notice:has-text("WP_Scripts::add"),
            .notice:has-text("WP_Styles::add"),
            .notice:has-text("elementor-v2-editor"),
            p:contains("WP_Scripts::add"),
            p:contains("WP_Styles::add"),
            p:contains("elementor-v2-editor"),
            div:contains("WP_Scripts::add"),
            div:contains("WP_Styles::add") {
                display: none !important;
                visibility: hidden !important;
                height: 0 !important;
                overflow: hidden !important;
            }
        </style>';
    }, 999 );
    
    // Add JavaScript to remove notices after page load
    add_action( 'admin_footer', function() {
        echo '<script>
        (function() {
            // Remove Elementor notices immediately
            function removeElementorNotices() {
                var notices = document.querySelectorAll("p, div, .notice");
                notices.forEach(function(el) {
                    var text = el.textContent || el.innerText || "";
                    if ((text.indexOf("WP_Scripts::add") !== -1 || 
                         text.indexOf("WP_Styles::add") !== -1) &&
                        (text.indexOf("elementor") !== -1 || 
                         text.indexOf("elementor-v2") !== -1)) {
                        el.style.display = "none";
                        el.style.visibility = "hidden";
                        el.style.height = "0";
                        el.style.overflow = "hidden";
                        el.remove();
                    }
                });
            }
            
            // Run immediately
            removeElementorNotices();
            
            // Run after DOM is ready
            if (document.readyState === "loading") {
                document.addEventListener("DOMContentLoaded", removeElementorNotices);
            } else {
                removeElementorNotices();
            }
            
            // Run after a short delay to catch dynamically added notices
            setTimeout(removeElementorNotices, 100);
            setTimeout(removeElementorNotices, 500);
            setTimeout(removeElementorNotices, 1000);
            
            // Use MutationObserver to catch notices added dynamically
            if (window.MutationObserver) {
                var observer = new MutationObserver(function(mutations) {
                    removeElementorNotices();
                });
                observer.observe(document.body, {
                    childList: true,
                    subtree: true
                });
            }
        })();
        </script>';
    }, 999 );
}

/**
 * Load PHP-based translations and register gettext filter.
 *
 * Looks for languages/{locale_prefix}.php (e.g. languages/ar.php).
 * This is a reliable fallback that does not depend on .mo files.
 *
 * @return void
 */
function med_calc_load_php_translations() {
    $locale = determine_locale();

    // Try exact locale first (e.g. ar_SA), then language prefix (e.g. ar)
    $candidates = array( $locale );
    if ( strpos( $locale, '_' ) !== false ) {
        $candidates[] = substr( $locale, 0, strpos( $locale, '_' ) );
    }

    $translations = null;
    foreach ( $candidates as $candidate ) {
        $file = MED_CALC_PLUGIN_DIR . 'languages/' . $candidate . '.php';
        if ( file_exists( $file ) ) {
            $translations = include $file;
            break;
        }
    }

    if ( ! is_array( $translations ) || empty( $translations ) ) {
        return;
    }

    // Store translations in a global so the filter callback can access them.
    $GLOBALS['_med_calc_php_translations'] = $translations;

    // Hook into WordPress gettext system for our text domain.
    add_filter( 'gettext',              'med_calc_gettext_filter', 5, 3 );
    add_filter( 'gettext_with_context', 'med_calc_gettext_with_context_filter', 5, 4 );
    add_filter( 'ngettext',             'med_calc_ngettext_filter', 5, 5 );
}

/**
 * Gettext filter — provides PHP-based translations for 'med-calculators' domain.
 *
 * @param string $translated Translated text (may still be English if .mo failed).
 * @param string $text       Original text.
 * @param string $domain     Text domain.
 * @return string Translated text.
 */
function med_calc_gettext_filter( $translated, $text, $domain ) {
    if ( 'med-calculators' !== $domain ) {
        return $translated;
    }
    if ( isset( $GLOBALS['_med_calc_php_translations'][ $text ] ) ) {
        return $GLOBALS['_med_calc_php_translations'][ $text ];
    }
    return $translated;
}

/**
 * Gettext with context filter.
 *
 * @param string $translated Translated text.
 * @param string $text       Original text.
 * @param string $context    Context.
 * @param string $domain     Text domain.
 * @return string Translated text.
 */
function med_calc_gettext_with_context_filter( $translated, $text, $context, $domain ) {
    if ( 'med-calculators' !== $domain ) {
        return $translated;
    }
    if ( isset( $GLOBALS['_med_calc_php_translations'][ $text ] ) ) {
        return $GLOBALS['_med_calc_php_translations'][ $text ];
    }
    return $translated;
}

/**
 * Ngettext filter — handles plural translations for 'med-calculators' domain.
 *
 * @param string $translated Translated text.
 * @param string $single     Singular form.
 * @param string $plural     Plural form.
 * @param int    $number     Number for plural decision.
 * @param string $domain     Text domain.
 * @return string Translated text.
 */
function med_calc_ngettext_filter( $translated, $single, $plural, $number, $domain ) {
    if ( 'med-calculators' !== $domain ) {
        return $translated;
    }
    // Look up the translated English string in our array
    if ( isset( $GLOBALS['_med_calc_php_translations'][ $translated ] ) ) {
        return $GLOBALS['_med_calc_php_translations'][ $translated ];
    }
    // Fallback: try the singular form as key
    if ( isset( $GLOBALS['_med_calc_php_translations'][ $single ] ) ) {
        return $GLOBALS['_med_calc_php_translations'][ $single ];
    }
    return $translated;
}

/**
 * Activation hook
 */
function med_calc_activate() {
    // Flush rewrite rules on activation
    flush_rewrite_rules();
    
    // Create database table
    $database = new Med_Calc_Database();
    $database->create_table();
    
    // Set plugin version in database
    update_option( 'med_calc_version', MED_CALC_VERSION );
    
    // Set default settings if not exists
    $default_settings = array(
        'output_mode' => 'instant', // instant, email_first, email_only
        'enable_email' => 0,
        'enable_logging' => 1,
        'require_email' => 0,
        'require_name' => 0,
        'gdpr_enabled' => 1,
        'privacy_text' => __( 'Your data is protected and will not be shared with third parties.', 'med-calculators' ),
    );
    
    $existing_settings = get_option( 'med_calc_settings', array() );
    $settings = wp_parse_args( $existing_settings, $default_settings );
    update_option( 'med_calc_settings', $settings );
}
register_activation_hook( __FILE__, 'med_calc_activate' );

/**
 * Deactivation hook
 */
function med_calc_deactivate() {
    // Flush rewrite rules on deactivation
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'med_calc_deactivate' );

/**
 * Helper function to get plugin setting
 *
 * @param string $key     Setting key.
 * @param mixed  $default Default value if setting not found.
 * @return mixed Setting value.
 */
function med_calc_get_setting( $key, $default = null ) {
    $settings = get_option( 'med_calc_settings', array() );
    return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
}